#imports
from flask import Flask, redirect, url_for, render_template, request, session, flash
from datetime import timedelta
app = Flask(__name__)
#flask code
app.permanent_session_lifetime = timedelta(days=10)
app.secret_key = "amin"

@app.route('/')
def homepage():
    if 'user' in session:
        return render_template('sesudahlogin.html', user = session['user'])
    else:
        return render_template('sebelumlogin.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if 'user' in session:
        return redirect(url_for('homepage'))
    else:
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            
            if username == password:
                session['user'] = username
                if 'simpan' in session:
                    return redirect(url_for('galogingabisa'))
                else:
                    return redirect(url_for('homepage'))
            else:
                flash("username dan passwor salah cuy")
                return render_template('login.html')

        else:
            return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('homepage'))

@app.route('/galogingabisa')
def galogingabisa():
    if 'user' in session:
        return render_template('gaklogingabisa.html')
    else:
        session['simpan'] = 'hai'
        return redirect(url_for('login'))

@app.route('/semuabisa')
def semuabisa():
    return render_template('semuabisa.html')


if __name__ == "__main__":
    app.run()